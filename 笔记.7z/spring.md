# spring

## 1. 要返回json格式数据需要在类前加上@RestController

## 2. Post需要用body部分，需要在方法参数前加上@RequestBody

## 3. postRequest中body内的参数只对应了第一个参数？

requestbody只对应一个参数，在实体类中获取更多参数。

## 注解

### @RequestMapping

处理请求地址映射的注解

六个属性：

1. value：指定请求的实际地址，指定的地址可以是URI Template 模式
2. method：GET POST PUT DELETE
3. consumes：指定处理请求的提交内容类型（Content-Type），例如application/json, text/html;
4. produces：指定返回的内容类型，仅当request请求头中的(Accept)类型中包含该指定类型才返回；
5. params：指定request中必须包含某些参数值是，才让该方法处理。
6. headers：指定request中必须包含某些指定的header值，才能让该方法处理请求。

```java
@RequestMapping("/api/presetService/{version}")
@ApiVersion(1)
```

等于

```java
@RequestMapping("/api/presetService/v1/")
```

### @Api

1. tags:生成的api文档会根据tags分类
2. value:类似tags，不能有多个值

### @Target

@Target(ElementType.TYPE)——接口、类、枚举、注解
@Target(ElementType.FIELD)——字段、枚举的常量
@Target(ElementType.METHOD)——方法
@Target(ElementType.PARAMETER)——方法参数
@Target(ElementType.CONSTRUCTOR) ——构造函数
@Target(ElementType.LOCAL_VARIABLE)——局部变量
@Target(ElementType.ANNOTATION_TYPE)——注解
@Target(ElementType.PACKAGE)——包

### @Retention

**被它所注解的注解保留多久**，一共有三种策略，定义在RetentionPolicy枚举中.

从注释上看：

source：注解只保留在源文件，当Java文件编译成class文件的时候，注解被遗弃；被编译器忽略

class：注解被保留到class文件，但jvm加载class文件时候被遗弃，这是默认的生命周期

runtime：注解不仅被保存到class文件中，jvm加载class文件之后，仍然存在

这3个生命周期分别对应于：Java源文件(.java文件) ---> .class文件 ---> 内存中的字节码。

### @Qualifier

解决无法识别到底是哪个bean 的问题

### @Primary

无法识别用哪个时，默认用@primay注释的类



## 过滤器

两种方式实现

1. @WebFilter

实现Filter接口

重写三个方法

init() 会在程序初始化期间运行

doFilter() 前端有请求发送过来后，首先进入到doFilter方法

destroy() Filter结束后运行

2. FilterRegistrationBean

@Bean注解方式

新建一个过滤器配置类

通过FIlterRegistrationBean设置过滤条件

## 拦截器注入service为null

在拦截器配置类里通过@bean注解注入拦截器，然后在addInterceptors方法中把new一个拦截器改为getSessionInterceptor()，代码示例如下

错误示例

注册代码

```java
@Configuration
public class MyWebMvcConfigurer implements WebMvcConfigurer {
	
  @Override
  public void addInterceptors(InterceptorRegistry registry) {
    registry.addInterceptor(new SessionInterceptor()).excludePathPatterns("/static/**").addPathPatterns("/**");
  }
}
```

拦截器代码：

public class SessionInterceptor  implements HandlerInterceptor {
    @Autowired
    private IUserService  userService;

```java
@Override
public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o) throws Exception {
    return true;
}

@Override
public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {
    HttpSession session = httpServletRequest.getSession();
    String username = (String)session.getAttribute("userName");
    //获取请求信息的用户名获取对应的用户信息
    SysUser userInfo =userService.getUserInfoByUserName(username).get(0);
}
```

正确：

```java
@Configuration
public class MyWebMvcConfigurer implements WebMvcConfigurer {
  @Bean
  public SessionInterceptor getSessionInterceptor(){
    return new SessionInterceptor();
  }

  @Override
  public void addInterceptors(InterceptorRegistry registry) {
    registry.addInterceptor(getSessionInterceptor()).excludePathPatterns("/static/**").addPathPatterns("/**");
  }
}
```

注入为null的时候，是通过new的方式创建的拦截器，通过new出来的实例是没有交给spring进行管理的，没有被spring管理的实例，spring是无法自动注入bean的，所以为null。

## 登录功能

传入P/W，到DB验证正确性，验证成功，生产token，返回给前端，同时存入redis，失败，报错提示。



## 自动装配

@SpringBootApplication以下三个注释组成：

@Configuration(@SpringBootConfiguration实质就是一个@Configuration）
@EnableAutoConfiguration
@ComponentScan

@EnableAutoConfiguration作用就是从classpath中搜寻所有的META-INF/spring.factories配置文件，并将其中org.springframework.boot.autoconfigure.EnableutoConfiguration对应的配置项通过反射（Java Refletion）实例化为对应的标注了@Configuration的JavaConfig形式的IoC容器配置类，然后汇总为一个并加载到IoC容器。这些功能配置类要生效的话，会去classpath中找是否有该类的依赖类（也就是pom.xml必须有对应功能的jar包才行）并且配置类里面注入了默认属性值类，功能类可以引用并赋默认值。生成功能类的原则是自定义优先，没有自定义时才会使用自动装配类。

- 所以功能类能生效需要的条件：（1）spring.factories里面有这个类的配置类（一个配置类可以创建多个围绕该功能的依赖类）（2）pom.xml里面需要有对应的jar包



