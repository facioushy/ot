### 设置PostgreSQL管理员用户的密码并添加一个用户并添加一个测试数据库

[root@localhost hik]# su - postgres
-bash-4.2$ psql -c "alter user postgres with password 'hik12345+''"
ALTER ROLE
-bash-4.2$ createuser devops
-bash-4.2$ createdb testdb -O devops
-bash-4.2$ exit
logout
-bash-4.2$ exit
logout
[root@localhost pgsql]#.

以刚刚添加的用户身份登录，并将DataBase作为测试操作。
[root@localhost hik]# su - devops
[devops@vm-06 ~]$
[devops@vm-06 ~]$ psql -l
List of databases
Name | Owner | Encoding | Collate | Ctype | Access privileges
------------------------------------------------+----------------------
postgres | postgres | UTF8 | en_US.UTF-8 | en_US.UTF-8 |
template0 | postgres | UTF8 | en_US.UTF-8 | en_US.UTF-8 | =c/postgres +

|      |      |      |      | postgres=CTc/postgres template1 | postgres | UTF8 | en_US.UTF-8 | en_US.UTF-8 | =c/postgres + |
| ---- | ---- | ---- | ---- | ------------------------------- | -------- | ---- | ----------- | ----------- | ------------- |
|      |      |      |      | postgres=CTc/postgres testdb    | devops   | UTF8 | en_US.UTF-8 |             |               |

[devops@vm-06 ~]$ psql testdb
psql (9.2.23)
Type "help" for help.
testdb=> alter user devops with password 'hik12345+';
ALTER ROLE
testdb=> create table test (no int,name text );
CREATE TABLE
testdb=> insert into test (no,name) values (1,'devops');
INSERT 0 1s
testdb=>;
select * from test;
no | name
---+-------
1 | devops
(1 row)





## date和timestamp区别

date类型是Oracle常用的日期型变量，他的时间间隔是秒。两个日期型相减得到是两个时间的间隔，注意单位是“天”

timestamp是DATE类型的扩展，可以精确到小数秒（*fractional_seconds_precision），可以是* 0 to9，缺省是６。两个timestamp相减的话，不能直接的得到天数书，而是得到，多少天，多少小时，多少秒等