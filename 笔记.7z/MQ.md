# AMQ

## 启动AMQ

在linux-x86-64文件夹中启动activemq

./activemq start

/usr/local/rabbitmq/rabbitmq_server-3.8.14



## 消息中间件

发送者将消息发送给消息服务器，消息服务器将消息存放在若千队列中，在合适
的时候再将消息转发给接收者。

这种模式下，发送和接收是异步的，发送者无需等
待; 二者的生命周期未必相同: 发送消息的时候接收者不一定运行，接收消息的时候
发送者也不一定运行;一对多通信: 对于一个消息可以有多个接收者。

## 消息模型

P2P:点对点  Point-to-Point

Pub/Sub：发布订阅 Publish/Subscribe

### P2P

![img](https://img-blog.csdn.net/20180730140037985?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzM2ODA3ODYy/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

1. 每个消息只有一个消费者（Consumer）(即一旦被消费，消息就不再在消息队列中)
2. 发送者和接收者之间在时间上没有依赖性，也就是说当发送者发送了消息之后，不管接收者有没有正在运行，它不会影响到消息被发送到队列
3. 接收者在成功接收消息之后需向队列应答成功

应用场景：A用户和B用户发送消息

### Pub/Sub发布订阅

![img](https://img-blog.csdn.net/20180730140038152?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzM2ODA3ODYy/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

多个发布者将消息发送到Topic,系统将这些消息传递给多个订阅者

每个消息可以有多个消费者

发布者和订阅者之间有时间上的依赖性。针对某个主题（Topic）的订阅者，它必须创建一个订阅者之后，才能消费发布者的消息，而且为了消费消息，订阅者必须保持运行的状态。

为了缓和这样严格的时间相关性，JMS允许订阅者创建一个可持久化的订阅。这样，即使订阅者没有被激活（运行），它也能接收到发布者的消息。

应用场景

如果你希望发送的消息可以不被做任何处理、或者被一个消息者处理、或者可以被多个消费者处理的话，那么可以采用Pub/Sub模型

用户注册、订单修改库存、日志存储



## 持久订阅者和非持久订阅者区别

持久传输和非持久传输最大的区别是：采用持久传输时，传输的消息会保存到磁盘中(messages are persisted to disk/database)，即“存储转发”方式。先把消息存储到磁盘中，然后再将消息“转发”给订阅者。当Borker宕机 恢复后，消息还在。

采用非持久传输时，发送的消息不会存储到磁盘中。Borker宕机重启后，消息丢失。

### 消息的订阅类型

对于topic的消息，有两种订阅类型：Durable Subscribers 和 NonDurable Subscribers。

- 持久订阅者和非持久订阅者针对的Domain是Pub/Sub，而不是P2P
- 当Broker发送消息给订阅者时，如果订阅者处于 inactive 状态：持久订阅者可以收到消息，而非持久订阅者则收不到消息。

当持久订阅者处于 inactive 状态时，Broker需要为持久订阅者保存消息；会造成的影响是：如果持久订阅者订阅的消息太多则会溢出。(当消息投递成功之后，Broker就可以把消息删除了)

对于持久订阅者而言，只要订阅了某个Topic，就不用担心自己“离线”(inactive)后，错过某些消息。但是对于非持久订阅者：

1）生产者发送了若干个消息到Topic后，非持久订阅者才去订阅该Topic，则它会错过(收不到)在它订阅之前发送的消息。

2）生产者向Topic发送了若干个消息，而此时因网络中断原因或者非持久订阅者宕机时，非持久订阅者刚好不在线(inactive)，就会错过（收不到）生产者发送的消息。

3）从消息的角度而言，有些消息是实时消息(如，实时股票价格)，需要快速地消费掉，对消息进行持久化就没有太大的意义，而且会因为存储消息而造成一定的开销。

因此，为了提高非持久订阅者的可靠性，以及实时的消费消息，就需要：

1. 消息不进行持久化并缓存消息(Caching message for nondurable consumers)；
2. 对缓存的消息的消费策略

#### 消息不进行持久化并缓存消息

AMQ Broker可以为各种Topic缓存消息，缓存的消息只会发给retroactive consumer，并不会发送给持久订阅者，因此只要在创建Topic的时候指定相应的consumer为retroactive即可

#### 消息订阅恢复策略

订阅恢复策略的目的就是让retroactive consumer能够回到过去某个时间点消费它错过了的消息。比如说：生产者发送了消息A，消息B给Broker的Topic之后，retroactive consumer才订阅该Topic，订阅恢复策略就可以让retroactive consumer能收到在它订阅之前就已经发送的消息(消息A 和消息B)

#### 订阅恢复策略

FixedSizedSubscriptionRecoveryPolicy：是ActiveMQ默认的策略。该恢复订阅策略最大的特点是：开辟多大的内存缓存发送到该Topic的消息。

Fixed Count Subscription Recovery Policy：按照数量来缓存消息。即，允许Topic最大缓存多少条消息。

## 虚拟主题

消息发布者是正常的Topic模式，接收端是队列，不同集群中使用不同的前缀作为集群的名称，即可实现消费者集群分组。既要发布订阅，又要让消费者分组。



# RabbitMQ 

## User can only log in via localhost解决办法

cd到bin目录

添加用户:./rabbitmqctl add_user admin admin

这句话的意思是添加一个用户 账号是admin 密码是admin 

添加权限:./rabbitmqctl set_permissions -p "/" admin ".*" ".*" ".*"

这句的意思是给所有的虚拟机主机添加所有的权限

修改用户角色:./rabbitmqctl set_user_tags admin administrator 

这句话的意思是给admin添加一个标签 标签是administrator 设置完就可以用admin admin登录了

## 启动

1. systemctl start rabbitmq-server
2. *#或者* 
3. rabbitmq-server start -detached   *#以后台守护进程方式启动*

# 区别

