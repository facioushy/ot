# Redis

## 启动redis服务器

```
./reids-server (路径)/redis.conf
```

默认非后台启动

vim redis.conf改daemonize为yes

```
./redis-benchmark //用于进行redis性能测试的工具
./redis-check-dump //用于修复出问题的dump.rdb文件
./redis-cli //redis的客户端
./redis-server //redis的服务端
./redis-check-aof //用于修复出问题的AOF文件
./redis-sentinel //用于集群管理
```

## 启动redis客户端

```
$ ./redis-cli
```

## 关闭redis

```
redis-cli shutdown
```

## redis连接超时，6379端口连接不上

1. redis.conf中的bind 127.0.0.1注释掉 
2. redis.conf中的protected-mode设置为no(允许远程访问)
3. redis.conf中的daemonize设置为yes(表明需要在后台运行)
4. iptables -F清除安全组规则



在防火墙添加端口

iptables -A INPUT -p tcp --dport 6379 -j ACCEPT



## redis配置-idea中

新建一个类实现IRedisPropertyService接口，创建连接







